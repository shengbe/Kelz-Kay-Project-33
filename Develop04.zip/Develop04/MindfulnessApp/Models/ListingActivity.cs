using System.Collections.Generic;

namespace MindfulnessApp.Models
{
    public class ListingActivity
    {
        public string Name { get; set; }
        public string Description { get; set; }
        private static List<string> Items { get; set; } = new List<string>(); // Ensure it persists in the session

        public ListingActivity()
        {
            Name = "Listing Activity";
            Description = "List things that bring positivity to your life.";
        }

        public void AddItem(string item)
        {
            if (!string.IsNullOrEmpty(item))
                Items.Add(item);
        }

        public void RemoveItem(int index)
        {
            if (index >= 0 && index < Items.Count)
                Items.RemoveAt(index);
        }

        public void EditItem(int index, string newItem)
        {
            if (index >= 0 && index < Items.Count && !string.IsNullOrEmpty(newItem))
                Items[index] = newItem;
        }

        public List<string> GetItems()
        {
            return new List<string>(Items);
        }
    }
}
