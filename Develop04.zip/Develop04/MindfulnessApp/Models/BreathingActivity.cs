using System.Threading.Tasks;
using MindfulnessApp.Models; 
namespace MindfulnessApp.Models
{
    public class BreathingActivity : MindfulnessActivity
    {
        public BreathingActivity()
        {
            Name = "Breathing Activity";
            Description = "Relax and pace your breathing with guided countdown.";
        }

        public async Task StartBreathing()
        {
            for (int i = 0; i < Duration / 4; i++)
            {
                System.Console.Clear();
                System.Console.WriteLine("Breathe In...");
                await Task.Delay(3000);

                System.Console.Clear();
                System.Console.WriteLine("Breathe Out...");
                await Task.Delay(3000);
            }

            System.Console.WriteLine("Great job! You completed the Breathing Activity.");
        }
    }
}
