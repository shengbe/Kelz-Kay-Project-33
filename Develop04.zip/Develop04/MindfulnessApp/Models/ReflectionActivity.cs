using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using MindfulnessApp.Models; 
namespace MindfulnessApp.Models
{
    public class ReflectionActivity : MindfulnessActivity
    {
        private static readonly List<string> Prompts = new List<string>
        {
            "Think of a time when you helped someone in need.",
            "Recall a situation where you demonstrated great strength.",
            "Think of a moment where you overcame a significant challenge."
        };

        public ReflectionActivity()
        {
            Name = "Reflection Activity";
            Description = "Think deeply about past experiences to gain insights.";
        }

        public async Task StartReflection()
        {
            Random random = new Random();
            string prompt = Prompts[random.Next(Prompts.Count)];
            System.Console.WriteLine(prompt);
            await Task.Delay(Duration * 1000);

            System.Console.WriteLine("Reflection time completed.");
        }
    }
}
