using System.Threading.Tasks;
using MindfulnessApp.Models; 
namespace MindfulnessApp.Models
{
    public class MeditationActivity : MindfulnessActivity
    {
        public MeditationActivity()
        {
            Name = "Meditation Activity";
            Description = "Relax your mind with guided meditation.";
        }

        public async Task StartMeditation()
        {
            for (int i = 0; i < Duration / 5; i++)
            {
                System.Console.Clear();
                System.Console.WriteLine("Focus on your breath... Let go of distractions.");
                await Task.Delay(5000);
            }

            System.Console.WriteLine("You have completed your meditation session.");
        }
    }
}
