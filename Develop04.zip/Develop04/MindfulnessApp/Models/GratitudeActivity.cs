using System.Collections.Generic;

namespace MindfulnessApp.Models
{
    public class GratitudeActivity
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public List<string> Gratitudes { get; private set; }

        public GratitudeActivity()
        {
            Name = "Gratitude Activity";
            Description = "Reflect on what you're grateful for.";
            Gratitudes = new List<string>();
        }

        public void AddGratitude(string gratitude)
        {
            if (!string.IsNullOrEmpty(gratitude))
                Gratitudes.Add(gratitude);
        }

        public List<string> GetGratitudes()
        {
            return Gratitudes;
        }
    }
}
