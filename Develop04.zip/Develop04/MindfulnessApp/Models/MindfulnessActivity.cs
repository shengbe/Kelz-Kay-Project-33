namespace MindfulnessApp.Models
{
    public abstract class MindfulnessActivity
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public int Duration { get; set; }

        public MindfulnessActivity()
        {
            Duration = 30; // Default duration
        }

        public virtual void StartActivity()
        {
            System.Console.WriteLine($"Starting {Name}: {Description}");
        }
    }
}
