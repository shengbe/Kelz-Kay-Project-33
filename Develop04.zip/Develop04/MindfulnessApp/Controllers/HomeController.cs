using Microsoft.AspNetCore.Mvc;
using MindfulnessApp.Models;
using System.Collections.Generic;

namespace MindfulnessApp.Controllers
{
    public class HomeController : Controller
    {
        private static ListingActivity listingActivity = new ListingActivity();
        private static GratitudeActivity gratitudeActivity = new GratitudeActivity();

        public IActionResult Index() => View();

        public IActionResult Breathing() => View();
        public IActionResult Reflection() => View();
        public IActionResult Listing() { ViewBag.Items = listingActivity.GetItems(); return View(); }
        public IActionResult Meditation() => View();
        public IActionResult Gratitude() { ViewBag.Gratitudes = gratitudeActivity.GetGratitudes(); return View(); }

        [HttpPost]
        public IActionResult AddGratitude(string gratitude)
        {
            gratitudeActivity.AddGratitude(gratitude);
            return RedirectToAction("Gratitude");
        }
        [HttpPost]
public IActionResult AddToList(string item)
{
    listingActivity.AddItem(item);
    return RedirectToAction("Listing");
}

[HttpPost]
public IActionResult RemoveFromList(int index)
{
    listingActivity.RemoveItem(index);
    return RedirectToAction("Listing");
}

[HttpPost]
public IActionResult EditList(int index, string newItem)
{
    listingActivity.EditItem(index, newItem);
    return RedirectToAction("Listing");
}

    }
}
